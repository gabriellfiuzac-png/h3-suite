# H3 Exact Master Audio + Memory Sampler

For long prerecorded dialogue/song/music where the final soundtrack must remain
the original recording.

Recommended: REF2VA, Sage, 20 steps, RES multistep/simple, one strong fixed
identity reference, memory=2, anchor=1.

The node returns video frames plus the untouched master-audio timeline. Do not
replace that audio with generated H3 audio.
